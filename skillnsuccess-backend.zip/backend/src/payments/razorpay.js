const crypto = require('crypto');
const Razorpay = require('razorpay');

// Lazy singleton: do NOT construct the Razorpay client at module-load time.
// The SDK throws synchronously if key_id/key_secret are missing, which would
// crash the whole server on boot — including the assessment/scoring routes
// that have nothing to do with payments. Since payments are optional until
// ENABLE_PAYMENTS=true, construction is deferred until something actually
// tries to create an order.
let _client = null;
function getClient() {
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    throw new Error('Razorpay is not configured — set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to enable payments.');
  }
  if (!_client) {
    _client = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  }
  return _client;
}

async function createOrder({ amount, currency, receipt, notes }) {
  return getClient().orders.create({ amount, currency, receipt, notes });
}

// Verifies the signature returned to the browser's checkout success handler.
// Per Razorpay docs: expected = HMAC_SHA256(order_id + "|" + payment_id, key_secret)
function verifyPaymentSignature({ orderId, paymentId, signature }) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  return expected === signature;
}

// Verifies webhook payloads sent by Razorpay's servers (Dashboard → Webhooks).
// Header: x-razorpay-signature. Body must be the raw request body (string).
function verifyWebhookSignature({ rawBody, signature }) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return expected === signature;
}

module.exports = { createOrder, verifyPaymentSignature, verifyWebhookSignature };
