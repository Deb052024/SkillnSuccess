const express = require('express');
const { nanoid } = require('nanoid');
const db = require('../db');

const router = express.Router();

router.post('/', (req, res) => {
  const { email, assessmentId } = req.body || {};
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'valid email required' });
  }

  const assessment = assessmentId
    ? db.prepare('SELECT * FROM assessments WHERE assessment_id = ?').get(assessmentId)
    : null;

  db.prepare(
    'INSERT INTO waitlist (waitlist_id, email, user_id, assessment_id) VALUES (?,?,?,?)'
  ).run(nanoid(), email, assessment ? assessment.user_id : null, assessmentId || null);

  res.json({ ok: true });
});

module.exports = router;
