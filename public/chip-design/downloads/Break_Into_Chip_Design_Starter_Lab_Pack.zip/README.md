# Break Into Chip Design — Starter Lab Pack

Four labs from the free starter chapter. Every result in the chapter came from running these files.

| Lab | Files | Run |
|---|---|---|
| D1 · 4-bit counter | counter4.v, tb_counter4.v | `iverilog -o sim counter4.v tb_counter4.v && vvp sim` |
| D2 · FIFO bug hunt | fifo_buggy.v, fifo_fixed.v, tb_fifo.v | `iverilog -o sim fifo_buggy.v tb_fifo.v && vvp sim` (then try fifo_fixed.v) |
| A1 · RC low-pass filter | rc_lowpass.cir, rc_10k.cir | `ngspice -b rc_lowpass.cir` |
| A2 · CMOS inverter | inverter.cir | `ngspice -b inverter.cir` |

No install? Paste the Verilog labs into EDA Playground (edaplayground.com) and pick Icarus Verilog.
Tools used: Icarus Verilog 12, ngspice 42. The inverter uses generic teaching models, not a foundry PDK.
